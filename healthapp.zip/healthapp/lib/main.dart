import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:firebase_core/firebase_core.dart';   // Needed to initialise Firebase

// Import all screens used in the app
import 'screens/welcome_screen.dart'; // Welcome / intro screen
import 'screens/login_screen.dart';  // Login page
import 'screens/register_screen.dart';  // Registration page
import 'screens/home_screen.dart'; // Welcome user to the app
import 'screens/learn_screen.dart'; // Learn section
import 'screens/puberty_screen.dart';   // Puberty topic page
import 'screens/ask_screen.dart'; // Ask Anything chatbot
import 'screens/clinic_screen.dart';  // Find a clinic map page
import 'screens/reminders_screen.dart'; // List of reminders
import 'screens/new_reminder_screen.dart'; // Create a new reminder
import 'screens/profile_screen.dart'; // User profile page
import 'screens/settings_screen.dart'; // App settings page
import 'screens/tutorial_screen.dart'; // Tutorial
import 'screens/contraception_screen.dart'; // Contraception topic page
import 'screens/emotions_screen.dart'; // Emotions topic page
import 'screens/pregnancy_screen.dart'; // Pregnancy topic page
import 'screens/cycle_screen.dart'; // Menstrual cycle topic page
import 'screens/hygiene_screen.dart'; // Hygiene topic page
import 'screens/about_screen.dart'; // About the app
import 'screens/feedback_screen.dart'; // Feedback submission page
import 'screens/saved_screen.dart'; // Saved articles page

//lab code firebase
void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Ensures Flutter is ready before Firebase loads
  await Firebase.initializeApp(); // Initialises Firebase for authentication + Firestore - wait to see if db is connected
  runApp(const HealthApp()); // Launches the main app widget
}

class HealthApp extends StatelessWidget {
  const HealthApp({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HealthApp', // App title shown in system UI
      debugShowCheckedModeBanner: false, // Removes the debug banner - https://api.flutter.dev/flutter/material/MaterialApp/debugShowCheckedModeBanner.html

      initialRoute: '/', // App starts on the Welcome screen

      // Route table mapping string paths to screen widgets
      routes: { //https://api.flutter.dev/flutter/material/MaterialApp/routes.html /https://docs.flutter.dev/cookbook/navigation/named-routes
        '/': (context) => const WelcomeScreen(), // Welcome screen
        '/login': (context) => const LoginScreen(),  // Login
        '/register': (context) => const RegisterScreen(), // Register
        '/home': (context) => const HomeScreen(),    // Home navigation
        '/learn': (context) => const LearnScreen(),  // Learn section
        '/puberty': (context) => const PubertyScreen(), // Puberty topic
        '/ask': (context) => const AskScreen(),      // Ask Anything chatbot
        '/clinics': (context) => const ClinicScreen(), // Clinic map
        '/reminders': (context) => const ReminderScreen(), // Reminder list
        '/newReminder': (context) => const NewReminderScreen(), // Add reminder
        '/profile': (context) => const ProfileScreen(), // Profile page
        '/settings': (context) => const SettingsScreen(), // Settings
        '/tutorial': (context) => const TutorialScreen(), // Tutorial
        '/contraception': (context) => const ContraceptionScreen(), // Contraception topic
        '/emotions': (context) => const EmotionsScreen(), // Emotions topic
        '/pregnancy': (context) => const PregnancyScreen(), // Pregnancy topic
        '/cycle': (context) => const CycleScreen(), // Menstrual cycle topic
        '/hygiene': (context) => const HygieneScreen(), // Hygiene topic
        '/about': (context) => const AboutScreen(), // About page
        '/saved': (context) => const SavedScreen(), // Saved articles
        '/feedback': (context) => const FeedbackScreen(), // Feedback page
      },
    );
  }
}