import 'package:flutter/material.dart'; // Flutter UI framework
import 'app_drawer.dart'; // app drawer widget
import 'app_topbar.dart'; // custom top bar widget

class AskScreen extends StatefulWidget { // ask screen widget
  const AskScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  State<AskScreen> createState() => _AskScreenState(); // create state
}

class _AskScreenState extends State<AskScreen> {

  final TextEditingController _controller = TextEditingController(); // input controller https://api.flutter.dev/flutter/widgets/TextEditingController-class.html

  List<Map<String, String>> messages = []; // chat messages list

  static const Color bg = Color(0xFFF7E7E4); // background colour
  static const Color userColor = Color(0xFFEAA6A0); // user bubble colour
  static const Color botColor = Colors.white; // bot bubble colour

  List<String> suggestions = [ // default suggestions
    "What changes happen during puberty?",
    "What is a normal menstrual cycle?",
    "How does contraception work?",
  ];

  void _sendMessage(String text) { // send message
    if (text.trim().isEmpty) return; // ignore empty

    setState(() {
      messages.add({ // add user message
        "sender": "user",
        "text": text,
      });

      String reply = _getBotReply(text); // get bot reply

      messages.add({ // add bot message
        "sender": "bot",
        "text": reply,
      });

      _updateSuggestions(text); // update suggestions
    });

    _controller.clear(); // clear input
  }

  String _getBotReply(String input) { // bot reply logic
    input = input.toLowerCase(); // lowercase for matching https://api.flutter.dev/flutter/dart-core/String/toLowerCase.html#:~:text=toLowerCase%20abstract%20method,-String%20toLowerCase()&text=Converts%20all%20characters%20in%20this,case%2C%20this%20method%20returns%20this%20.&text=This%20function%20uses%20the%20language,only%20works%20in%20some%20languages.

    //if, else https://dart.dev/language/branches
    if (input.contains("puberty")) {
      return "During puberty, your body changes physically and emotionally due to hormones.";
    }

    if (input.contains("cycle") || input.contains("period")) {
      return "A normal menstrual cycle lasts between 21–35 days.";
    }

    if (input.contains("contraception")) {
      return "Contraception helps prevent pregnancy. Methods include condoms, pill, implant and IUD.";
    }

    if (input.contains("pregnancy")) {
      return "Early pregnancy signs include missed period, nausea and tiredness.";
    }

    if (input.contains("emotion") || input.contains("mood")) {
      return "Hormones can affect mood. Emotional changes are normal.";
    }

    if (input.contains("hygiene")) {
      return "Good hygiene includes regular washing and changing sanitary products.";
    }

    return "Please consult a healthcare professional for medical advice."; // fallback
  }

  void _updateSuggestions(String input) { // update suggestions
    input = input.toLowerCase(); // https://api.flutter.dev/flutter/dart-core/String/toLowerCase.html#:~:text=toLowerCase%20abstract%20method,-String%20toLowerCase()&text=Converts%20all%20characters%20in%20this,case%2C%20this%20method%20returns%20this%20.&text=This%20function%20uses%20the%20language,only%20works%20in%20some%20languages.

    //https://dart.dev/language/branches
    if (input.contains("puberty")) {
      suggestions = [
        "Is mood change normal in puberty?",
        "When does puberty start?",
        "Why does my body change?",
      ];
    }
    else if (input.contains("cycle") || input.contains("period")) {
      suggestions = [
        "Why is my period irregular?",
        "How long should a period last?",
        "What causes period pain?",
      ];
    }
    else if (input.contains("contraception")) {
      suggestions = [
        "What is the safest contraception?",
        "Does the pill have side effects?",
        "Are condoms effective?",
      ];
    }
    else if (input.contains("pregnancy")) {
      suggestions = [
        "When should I take a pregnancy test?",
        "What are early symptoms?",
        "How soon can pregnancy be detected?",
      ];
    }
    else if (input.contains("emotion")) {
      suggestions = [
        "How can I manage mood swings?",
        "Why do hormones affect emotions?",
        "Is anxiety normal during puberty?",
      ];
    }
    else if (input.contains("hygiene")) {
      suggestions = [
        "How often should I change pads?",
        "What is good daily hygiene?",
        "Can poor hygiene cause infection?",
      ];
    }
    else {
      suggestions = [
        "Tell me about puberty",
        "Explain menstrual cycle",
        "What is contraception?",
      ];
    }
  }

  @override
  Widget build(BuildContext context) { // build UI
    return Scaffold(
      backgroundColor: bg, // set background colour
      drawer: const AppDrawer(), // app drawer

      body: SafeArea(
        child: Column(
          children: [

            const AppTopBar(title: "Ask anything"), // top bar title

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16), // padding
              child: Text(
                "This chatbot provides general information only.", // disclaimer
                style: TextStyle(fontSize: 12, color: Colors.red), // red text
              ),
            ),

            const SizedBox(height: 10), // spacing

            Expanded(
              child: ListView( //https://api.flutter.dev/flutter/widgets/ListView-class.html
                padding: const EdgeInsets.all(16), // list padding
                children: [

                  ...messages.map((message) { // .map() to loop through all messages and turn each one into a chat bubble on the screen https://api.dart.dev/dart-core/Iterable/map.html - https://dart.dev/language/collections#spread-operator
                    final isUser = message["sender"] == "user"; // check sender

                    return Align(
                      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft, // bubble alignment
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10), // spacing
                        padding: const EdgeInsets.all(12), // bubble padding
                        decoration: BoxDecoration(
                          color: isUser ? userColor : botColor, // bubble colour
                          borderRadius: BorderRadius.circular(16), // rounded corners
                        ),
                        child: Text(message["text"] ?? ""), // message text
                      ),
                    );
                  }),

                  const SizedBox(height: 10), // spacing

                  Column( // suggestions list
                    crossAxisAlignment: CrossAxisAlignment.start, // align left
                    children: suggestions.map((prompt) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8), // spacing
                        child: ActionChip( //https://api.flutter.dev/flutter/material/ActionChip-class.html
                          label: Text(prompt), // suggestion text
                          onPressed: () => _sendMessage(prompt), // send suggestion
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(12), // padding
              child: Row(
                children: [
                  Expanded(
                    child: TextField ( // adapted https://api.flutter.dev/flutter/material/TextField-class.html
                      controller: _controller, // input controller
                      decoration: const InputDecoration(
                        hintText: "Ask about health...", // placeholder
                        border: OutlineInputBorder(), // border //reference https://api.flutter.dev/flutter/material/OutlineInputBorder-class.html
                      ),
                      onSubmitted: _sendMessage, // send on enter
                    ),
                  ),
                  const SizedBox(width: 8), // spacing
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: userColor, // pink button
                      foregroundColor: Colors.white, // white icon
                    ),
                    onPressed: () => _sendMessage(_controller.text), // send message
                    child: const Icon(Icons.send), // send icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
