import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:firebase_auth/firebase_auth.dart'; // Firebase authentication

//adapted code from for app drawer https://docs.flutter.dev/cookbook/design/drawer
class AppDrawer extends StatelessWidget {
  // app drawer widget
  const AppDrawer({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  Widget build(BuildContext context) {
    // build UI

    const Color drawerColor = Color(0xFFFDF7F6); // drawer background colour

    return Drawer(
      backgroundColor: drawerColor, // set drawer colour

      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // align left
          children: [

            const Padding(
              padding: EdgeInsets.all(20), // padding around title
              child: Text(
                "HealthApp", // app name
                style: TextStyle(
                  fontSize: 24, // title size
                  fontWeight: FontWeight.bold, // bold text
                ),
              ),
            ),

            const Divider(),
            // separator

            _buildMenuItem(context, Icons.book, "Learn", '/learn'), // icon https://api.flutter.dev/flutter/material/Icons-class.html
            // learn page
            _buildMenuItem(context, Icons.chat, "Ask anything", '/ask'), // icon https://api.flutter.dev/flutter/material/Icons-class.html
            // ask page
            _buildMenuItem(
                context, Icons.location_on, "Find a clinic", '/clinics'), // icon https://api.flutter.dev/flutter/material/Icons-class.html
            // clinics page
            _buildMenuItem(context, Icons.alarm, "Reminders", '/reminders'), // icon https://api.flutter.dev/flutter/material/Icons-class.html
            // reminders page
            _buildMenuItem(context, Icons.bookmark, "Saved articles", '/saved'), // icon https://api.flutter.dev/flutter/material/Icons-class.html
            // saved articles
            _buildMenuItem(context, Icons.info, "About", '/about'), // icon https://api.flutter.dev/flutter/material/Icons-class.html
            // about page
            _buildMenuItem(context, Icons.feedback, "Feedback", '/feedback'), // icon https://api.flutter.dev/flutter/material/Icons-class.html
            // feedback page

            const Spacer(),
            // push logout to bottom

            const Divider(),
            // separator

            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              // logout icon
              title: const Text(
                "Log Out", // logout text
                style: TextStyle(
                  color: Colors.red, // red text
                  fontWeight: FontWeight.bold, // bold
                ),
              ),
              onTap: () async { // https://stackoverflow.com/questions/78049058/access-context-after-navigator-pop
                Navigator.pop(context); // close drawer
                await FirebaseAuth.instance.signOut(); // sign out user
                if (!context.mounted) return; // ensure widget active
                Navigator.pushNamedAndRemoveUntil( // https://api.flutter.dev/flutter/widgets/Navigator/pushNamedAndRemoveUntil.html
                  context,
                  '/', // go to welcome screen
                      (route) => false, //  removes all previous pages
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItem( // builds a single drawer menu item
      BuildContext context, // needed for navigation
      IconData icon, // icon to show on the left
      String title, // text label for the menu item
      String route, // route to navigate to when tapped
      ) {
    return ListTile( // clickable row in the drawer
      leading: Icon(icon), // icon displayed on the left
      title: Text(title), // menu item text
      onTap: () { // action when tapped
        Navigator.pop(context); // close the drawer
        Navigator.pushNamed(context, route); // navigate to the selected page
      },
    );
  }
}
