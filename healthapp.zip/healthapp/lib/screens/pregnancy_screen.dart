import 'package:flutter/material.dart';  // Flutter UI framework
import 'package:cloud_firestore/cloud_firestore.dart'; // Firestore for loading article content
import 'package:firebase_auth/firebase_auth.dart';  // Firebase auth for saving articles
import 'package:youtube_player_flutter/youtube_player_flutter.dart'; // YouTube player package

class PregnancyScreen extends StatefulWidget {  // Screen for pregnancy article + video
  const PregnancyScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  State<PregnancyScreen> createState() => _PregnancyScreenState();
}

class _PregnancyScreenState extends State<PregnancyScreen> {
  //adapted code https://pub.dev/packages/youtube_player_flutter
  late YoutubePlayerController _controller;  // Controller for YouTube video player

  @override
  void initState() {
    super.initState();

    //adapted code https://pub.dev/packages/youtube_player_flutter
    _controller = YoutubePlayerController(  // Initialise YouTube player
      initialVideoId: "6ZjA6IWCv2s", // YouTube video ID
      flags: const YoutubePlayerFlags(
        autoPlay: false,  // Do not auto-play
        mute: false, // Sound enabled
      ),
    );
  }

  // Splits article text into paragraphs and formats headings
  List<Widget> _buildFormattedContent(String content) {
    final paragraphs = content
        .split('\n\n') // Split text by blank lines https://api.dart.dev/stable/dart-core/String/split.html
        .where((p) => p.trim().isNotEmpty) // Remove empty sections - https://api.dart.dev/stable/dart-core/Iterable/where.html https://api.dart.dev/stable/dart-core/String/trim.html
        .toList(); //https://api.dart.dev/dart-core/Iterable/toList.html

    return paragraphs.map((paragraph) {
      final text = paragraph.trim();  // Clean whitespace - https://api.dart.dev/stable/dart-core/String/trim.html
      final isHeading = text.endsWith(':'); // Detect headings by colon https://api.dart.dev/dart-core/String/endsWith.html

      return Padding(
        padding: const EdgeInsets.only(bottom: 14), // Space between paragraphs
        child: Text(
          text,
          style: TextStyle(
            fontSize: isHeading ? 18 : 16, // Larger font for headings
            fontWeight: isHeading ? FontWeight.bold : FontWeight.normal,
            height: 1.7, // Line spacing
            color: Colors.black87, // Text colour
          ),
        ),
      );
    }).toList();// https://api.dart.dev/dart-core/Iterable/toList.html
  }

  @override
  void dispose() {
    _controller.dispose(); // Dispose YouTube controller //adapted code https://pub.dev/packages/youtube_player_flutter
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7E7E4), // Soft blush background
      body: SafeArea(
        child: FutureBuilder<DocumentSnapshot>( // Load article from Firestore - lab code
          future: FirebaseFirestore.instance //future is for something that happens one time and then stops.
              .collection('learn_topics') // Collection of learning topics
              .doc('pregnancy') // Document for pregnancy topic
              .get(),
          builder: (context, snapshot) { //lab code
            if (!snapshot.hasData) { // While loading
              return const Center(child: CircularProgressIndicator());
            }
            if (!snapshot.data!.exists) { // If no article found
              return const Center(child: Text("No pregnancy content found."));
            }

            final data = snapshot.data!.data() as Map<String, dynamic>; // Convert to map - lab code
            final title = (data['title'] ?? '').toString();   // Article title
            final content = (data['content'] ?? '').toString(); // Article body text

            return SingleChildScrollView(
              padding: const EdgeInsets.all(16), // Page padding
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  IconButton(
                    icon: const Icon(Icons.arrow_back), // Back button // icon https://api.flutter.dev/flutter/material/Icons-class.html
                    onPressed: () => Navigator.pop(context),
                  ),

                  Text(
                    title, // Display article title
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 10),

                  ElevatedButton.icon(
                    icon: const Icon(Icons.bookmark, color: Colors.pink), // icon https://api.flutter.dev/flutter/material/Icons-class.html
                    label: const Text(
                      "Save Article",
                      style: TextStyle(color: Colors.pink),
                    ),
                    onPressed: () async { //lab code authentication
                      final user = FirebaseAuth.instance.currentUser; // Current user
                      if (user == null) return; // Stop if not logged in

                      await FirebaseFirestore.instance
                          .collection('saved_articles')  // Save to saved_articles
                          .add({
                        'userEmail': user.email, // Who saved it
                        'title': title, // Article title
                        'content': content, // Article content
                        'route': '/pregnancy', // Route to reopen article
                        'createdAt': Timestamp.now(), // Timestamp
                      });

                      if (!context.mounted) return; // ensure widget still active https://api.flutter.dev/flutter/widgets/Element/mounted.html

                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Article saved")), // Confirmation message
                      );
                    },
                  ),

                  const SizedBox(height: 12),

                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: _buildFormattedContent(content), // Render formatted paragraphs
                  ),

                  const SizedBox(height: 25),

                  Container(
                    padding: const EdgeInsets.all(14), // Padding around video section
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Colors.white,
                        width: 4,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        const Row(
                          children: [
                            Icon(Icons.play_circle_fill, // icon https://api.flutter.dev/flutter/material/Icons-class.html
                                color: Colors.pinkAccent), // Video icon
                            SizedBox(width: 8),
                            Text(
                              "Watch & Learn", // Section title
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 6),

                        const Text(
                          "Pregnancy Explained", // Video description
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.black54,
                          ),
                        ),

                        const SizedBox(height: 12),

                        //https://api.flutter.dev/flutter/widgets/ClipRRect-class.html
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12), // Rounded video corners
                          child: AspectRatio(
                            aspectRatio: 16 / 9, // Standard video ratio
                            //https://pub.dev/packages/youtube_player_flutter
                            child: YoutubePlayer(
                              controller: _controller, // YouTube player widget
                              showVideoProgressIndicator: true, // Show progress bar
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}