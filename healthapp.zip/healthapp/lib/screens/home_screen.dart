import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:firebase_auth/firebase_auth.dart'; // Firebase authentication

class HomeScreen extends StatelessWidget { // Home screen widget
  const HomeScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  String _firstNameFromEmail(String? email) { // extract first name from email
    if (email == null || email.trim().isEmpty) return "User"; // fallback https://api.flutter.dev/flutter/dart-core/String/trim.html
    final name = email.split('@').first.trim(); // take part before @ - https://api.flutter.dev/flutter/dart-core/String/split.html
    return name.isEmpty ? "User" : name; // fallback if empty
  }

  @override
  Widget build(BuildContext context) { // build UI
    const bg = Color(0xFFF7E7E4); // background colour
    const card = Color(0xFFFDF7F6); // card background
    const accent = Color(0xFFEAA6A0); // accent colour

    final user = FirebaseAuth.instance.currentUser; // current user stored
    final firstName = _firstNameFromEmail(user?.email); // extract first name https://pub.dev/documentation/firebase_auth/latest/firebase_auth/User-class.html

    return Scaffold(
      backgroundColor: bg, // set background colour
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView( // scroll for small screens
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24), // page padding
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420), // limit width
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch, // stretch children
                children: [
                  const SizedBox(height: 10), // spacing

                  Container( // top icon circle
                    width: 96, // width
                    height: 96, // height
                    alignment: Alignment.center, // center icon
                    decoration: BoxDecoration(
                      color: Colors.white, // white background
                      shape: BoxShape.circle, // circular shape
                      border: Border.all(color: Colors.black12), // border
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 16, // shadow blur
                          offset: Offset(0, 8), // shadow offset
                          color: Color(0x14000000), // shadow colour
                        ),
                      ],
                    ),
                    child: const Icon(Icons.favorite, size: 40, color: accent), // heart icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                  ),

                  const SizedBox(height: 14), // spacing

                  Text(
                    "Welcome, $firstName", // greeting text
                    textAlign: TextAlign.center, // center text
                    style: const TextStyle(
                      fontSize: 24, // font size
                      fontWeight: FontWeight.w900, // heavy weight
                    ),
                  ),

                  const SizedBox(height: 6), // spacing

                  const Text(
                    "Your health journey starts here.", // subtitle
                    textAlign: TextAlign.center, // center text
                    style: TextStyle(color: Colors.black54, height: 1.3), // grey text
                  ),

                  const SizedBox(height: 18), // spacing

                  Container( // main card
                    padding: const EdgeInsets.all(18), // inner padding
                    decoration: BoxDecoration(
                      color: card, // card background
                      borderRadius: BorderRadius.circular(18), // rounded corners
                      border: Border.all(color: Colors.black12), // border
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 18, // blur
                          offset: Offset(0, 10), // offset
                          color: Color(0x14000000), // shadow colour
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch, // stretch children
                      children: [
                        const Text(
                          "Start learning", // section title
                          textAlign: TextAlign.center, // center text
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800), // style
                        ),

                        const SizedBox(height: 8), // spacing

                        const Text(
                          "Explore trusted topics like puberty, contraception, emotions, pregnancy, your cycle and hygiene.", // description
                          textAlign: TextAlign.center, // center text
                          style: TextStyle(color: Colors.black54, height: 1.35), // grey text
                        ),

                        const SizedBox(height: 16), // spacing

                        SizedBox(
                          height: 50, // button height
                          child: ElevatedButton( // get started button
                            style: ElevatedButton.styleFrom(
                              backgroundColor: accent, // pink background
                              foregroundColor: Colors.white, // white text
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14), // rounded corners
                              ),
                            ),
                            onPressed: () => Navigator.pushNamed(context, '/learn'), // go to learn screen https://api.flutter.dev/flutter/widgets/Navigator/pushNamed.html
                            child: const Text(
                              "Get Started", // button text
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800), // style
                            ),
                          ),
                        ),

                        const SizedBox(height: 10), // spacing

                        SizedBox(
                          height: 50, // button height
                          child: OutlinedButton( // tutorial button
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Colors.black12), // border
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14), // rounded corners
                              ),
                              backgroundColor: Colors.white, // white background
                            ),
                            onPressed: () => Navigator.pushNamed(context, '/tutorial'), // go to tutorial https://api.flutter.dev/flutter/widgets/Navigator/pushNamed.html
                            child: const Text(
                              "Watch Tutorial", // button text
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800), // style
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 18), // bottom spacing
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
