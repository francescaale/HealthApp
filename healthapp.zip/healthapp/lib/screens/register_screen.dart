import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:firebase_auth/firebase_auth.dart';  // Firebase authentication service

class RegisterScreen extends StatefulWidget { // screen for creating a new account
  const RegisterScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  State<RegisterScreen> createState() => _RegisterScreenState(); // create state
}

class _RegisterScreenState extends State<RegisterScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>(); // form validation key

  final TextEditingController _emailController = TextEditingController(); // email input lab code
  final TextEditingController _passwordController = TextEditingController(); // password input lab code
  final TextEditingController _confirmController = TextEditingController(); // confirm password input

  bool _loading = false; // loading spinner state https://api.flutter.dev/flutter/dart-core/bool-class.html
  bool _hidePassword = true; // toggle password visibility https://api.flutter.dev/flutter/dart-core/bool-class.html
  bool _hideConfirm = true; // toggle confirm visibility https://api.flutter.dev/flutter/dart-core/bool-class.html
  String _message = ""; // error message text

  @override
  void dispose() { // cleanup controllers
    _emailController.dispose();  //lab code
    _passwordController.dispose(); //lab code
    _confirmController.dispose();
    super.dispose();
  }

  String _registerError(String code, String? fallback) { // convert Firebase errors - extension work code lab errors
    switch (code) {
      case 'email-already-in-use': return 'This email is already registered.';
      case 'invalid-email': return 'That email address is not valid.';
      case 'weak-password': return 'Password is too weak (min 6 characters).';
      case 'network-request-failed': return 'Network error. Check your internet connection.';
      case 'operation-not-allowed': return 'Enable Email/Password in Firebase Console.';
      default: return fallback ?? 'Registration failed.';
    }
  }

  Future<void> _register() async { // handle sign-up - future is for something that happens one time and then stops.
    FocusScope.of(context).unfocus(); // removes focus from the text field, which dismisses the on-screen keyboard after user interaction https://api.flutter.dev/flutter/widgets/FocusScope-class.html https://api.flutter.dev/flutter/widgets/FocusNode/unfocus.html

    if (!_formKey.currentState!.validate()) return; // If form is not valid (empty fields), stop here - lab code

    setState(() {
      _loading = true; // show spinner
      _message = ""; // clear old errors
    });

    try {
      final userCredential =
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text.trim(), // trimmed email
        password: _passwordController.text.trim(), // trimmed password
      );

      if (userCredential.user != null) { // success
        if (!mounted) return;
        Navigator.pushNamedAndRemoveUntil( //https://api.flutter.dev/flutter/widgets/Navigator/pushNamedAndRemoveUntil.html
          context,
          '/home', // go to home
              (route) => false, // clear stack
        );
      }

    } on FirebaseAuthException catch (e) { // Firebase errors //https://dart.dev/language/error-handling
      setState(() {
        _message = _registerError(e.code, e.message); // friendly message
      });

    } catch (e) { // unexpected error //https://dart.dev/language/error-handling
      setState(() {
        _message = "Something went wrong. Please try again."; // generic error
      });

    } finally {
      if (mounted) setState(() => _loading = false); // stop spinner
    }
  }

  @override
  Widget build(BuildContext context) { // build UI
    const bg = Color(0xFFF7E7E4); // background colour
    const card = Color(0xFFFDF7F6); // card background
    const accent = Color(0xFFEAA6A0); // pink accent

    return Scaffold(
      backgroundColor: bg, // set background
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView( // scroll on small screens
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420), // narrow layout
              child: Column(
                children: [
                  const SizedBox(height: 10),

                  Container( // top circular icon
                    width: 96,
                    height: 96,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.black12),
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 16,
                          offset: Offset(0, 8),
                          color: Color(0x14000000),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.person_add_alt_1, // add-user icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                      size: 38,
                      color: accent,
                    ),
                  ),

                  const SizedBox(height: 12),

                  const Text(
                    "HealthApp", // app title
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                  ),

                  const SizedBox(height: 16),

                  Container( // form card
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: card,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.black12),
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 18,
                          offset: Offset(0, 10),
                          color: Color(0x14000000),
                        ),
                      ],
                    ),

                    child: Form(
                      key: _formKey, // attach form key
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [

                          const Text(
                            "Create Account", // form title
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                          ),

                          const SizedBox(height: 6),

                          const Text(
                            "Create an account to access all learning content.", // subtitle
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.black54),
                          ),

                          const SizedBox(height: 18),

                          TextFormField( // email field
                            controller: _emailController,
                            keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(
                              labelText: "Email",
                              hintText: "hello@gmail.com",
                              filled: true,
                              fillColor: Colors.white,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                            validator: (value) { // lab code
                              final text = (value ?? '').trim();
                              if (text.isEmpty) return "Email is required.";
                              if (!text.contains('@')) return "Enter a valid email.";
                              return null;
                            },
                          ),

                          const SizedBox(height: 12),

                          TextFormField( // password field
                            controller: _passwordController,
                            obscureText: _hidePassword,
                            decoration: InputDecoration(
                              labelText: "Password",
                              hintText: "At least 6 characters",
                              filled: true,
                              fillColor: Colors.white,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                              suffixIcon: IconButton( // visibility toggle
                                onPressed: () {
                                  setState(() => _hidePassword = !_hidePassword); // toggle state
                                },
                                icon: Icon(
                                  _hidePassword
                                      ? Icons.visibility_off
                                      : Icons.visibility, // icon https://api.flutter.dev/flutter/material/Icons-class.html
                                ),
                              ),
                            ),
                            validator: (value) { // lab code
                              final text = (value ?? '').trim();
                              if (text.isEmpty) return "Password is required.";
                              if (text.length < 6) return "Min 6 characters.";
                              return null;
                            },
                          ),

                          const SizedBox(height: 12),

                          TextFormField( // confirm password field
                            controller: _confirmController,
                            obscureText: _hideConfirm,
                            decoration: InputDecoration(
                              labelText: "Confirm Password",
                              hintText: "Repeat password",
                              filled: true,
                              fillColor: Colors.white,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                              suffixIcon: IconButton(
                                onPressed: () {
                                  setState(() => _hideConfirm = !_hideConfirm); // toggle
                                },
                                icon: Icon(
                                  _hideConfirm
                                      ? Icons.visibility_off
                                      : Icons.visibility, // icon https://api.flutter.dev/flutter/material/Icons-class.html
                                ),
                              ),
                            ),
                            validator: (value) {
                              final text = (value ?? '').trim();
                              if (text.isEmpty) return "Confirm your password.";
                              if (text != _passwordController.text.trim()) {
                                return "Passwords do not match.";
                              }
                              return null;
                            },
                          ),

                          const SizedBox(height: 10),

                          if (_message.isNotEmpty) ...[ // show error if exists https://api.dart.dev/dart-core/String/isNotEmpty.html
                            Container( // error box
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Color(0xFFFFE6E6),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Color(0x33FF0000)),
                              ),
                              child: Row(
                                children: [
                                  const Icon(Icons.error_outline, color: Colors.red), // icon https://api.flutter.dev/flutter/material/Icons-class.html
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      _message, // error text
                                      style: TextStyle(color: Colors.red),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 10),
                          ],

                          SizedBox(
                            height: 50,
                            child: ElevatedButton( // sign up button
                              style: ElevatedButton.styleFrom(
                                backgroundColor: accent,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                              onPressed: _loading ? null : _register, // disable if loading
                              child: _loading
                                  ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2), // spinner https://api.flutter.dev/flutter/material/CircularProgressIndicator-class.html
                              )
                                  : const Text(
                                "Sign up",
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),

                          const SizedBox(height: 14),

                          Row( // login link
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text("Already have an account? "),
                              TextButton(
                                onPressed: () {
                                  Navigator.pushReplacementNamed(context, '/login'); // go to login https://api.flutter.dev/flutter/widgets/Navigator/pushReplacementNamed.html
                                },
                                child: const Text("Login"),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}