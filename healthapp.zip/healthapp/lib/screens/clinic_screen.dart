import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:google_maps_flutter/google_maps_flutter.dart'; // Google Maps widget
import 'package:permission_handler/permission_handler.dart'; // location permissions
import 'package:cloud_firestore/cloud_firestore.dart'; // Firestore database

import 'app_drawer.dart'; // app drawer widget
import 'app_topbar.dart'; // custom top bar widget

class ClinicScreen extends StatefulWidget { // clinic screen widget
  const ClinicScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  State<ClinicScreen> createState() => _ClinicScreenState(); // create state
}

class _ClinicScreenState extends State<ClinicScreen> {
  static const Color bg = Color(0xFFF7E7E4); // background colour

  final List<Marker> _markers = []; // list of map markers
  GoogleMapController? _mapController; // map controller

  final LatLng _startLocation = const LatLng(52.954783, -1.150617); // default map center

  //adapted map lab code
  @override
  void initState() { // initialize state
    super.initState();
    Permission.locationWhenInUse.request(); // request location permission
    _loadClinicMarkers(); // load clinic markers
  }

  //adapted map lab code
  @override
  void dispose() { // cleanup
    _mapController?.dispose(); // dispose map controller
    super.dispose();
  }

  //adapted lab code firebase + map
  Future<void> _loadClinicMarkers() async { // load markers from Firestore - using future void rather than stream because loading markers is a one‑time task, not a continuous stream of updates.
    final snapshot =
    await FirebaseFirestore.instance.collection('clinics').get(); // fetch clinics

    final List<Marker> loaded = []; // temporary list

    for (var doc in snapshot.docs) { // loop through documents
      final data = doc.data(); // clinic data

      if (data['latitude'] == null || data['longitude'] == null) continue; // skip invalid

      final double lat = (data['latitude'] as num).toDouble(); // latitude
      final double lng = (data['longitude'] as num).toDouble(); // longitude

      loaded.add(
        Marker(
          markerId: MarkerId(doc.id), // unique marker ID
          position: LatLng(lat, lng), // marker position
          infoWindow: InfoWindow(
            title: data['name'] ?? 'Clinic', // clinic name
            snippet: data['type'] ?? '', // clinic type
          ),
        ),
      );
    }

    setState(() {
      _markers.clear(); // clear old markers
      _markers.addAll(loaded); // add new markers
    });
  }

  @override
  Widget build(BuildContext context) { // build UI
    return Scaffold(
      backgroundColor: bg, // set background colour
      drawer: const AppDrawer(), // app drawer
      body: SafeArea(
        child: Column(
          children: [
            const AppTopBar(title: "Find a clinic"), // top bar title
            Expanded(
              child: GoogleMap(
                myLocationEnabled: true, // show user location
                mapType: MapType.normal, // normal map style
                initialCameraPosition: CameraPosition(
                  target: _startLocation, // initial map center
                  zoom: 13, // zoom level
                ),
                markers: _markers.toSet(), // display markers
              ),
            ),
          ],
        ),
      ),
    );
  }
}