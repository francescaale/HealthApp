import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:cloud_firestore/cloud_firestore.dart'; // Firestore database
import 'app_drawer.dart'; // App drawer widget
import 'app_topbar.dart'; // Custom top bar widget

class FeedbackScreen extends StatefulWidget { // Feedback screen widget
  const FeedbackScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  State<FeedbackScreen> createState() => _FeedbackScreenState(); // create state
}

class _FeedbackScreenState extends State<FeedbackScreen> {

  final TextEditingController _controller = TextEditingController(); // input controller https://api.flutter.dev/flutter/widgets/TextEditingController-class.html
  String _message = ""; // status message

  static const Color bg = Color(0xFFF7E7E4); // background colour
  static const Color accent = Color(0xFFEAA6A0); // accent colour

  void _submit() async { // submit feedback
    final text = _controller.text.trim(); // get trimmed text https://api.flutter.dev/flutter/dart-core/String/trim.html

    if (text.isEmpty) { // check empty
      setState(() => _message = "Please write something."); // show error
      return;
    }

    await FirebaseFirestore.instance.collection('feedback').add({ // save to Firestore lab code
      'message': text, // feedback message
      'timestamp': DateTime.now(), // timestamp
    });

    setState(() {
      _message = "Thank you for your feedback!"; // success message
      _controller.clear(); // clear input https://api.flutter.dev/flutter/dart-core/List/clear.html
    });
  }

  @override
  Widget build(BuildContext context) { // build UI
    return Scaffold(
      backgroundColor: bg, // set background colour
      drawer: const AppDrawer(), // drawer menu

      body: SafeArea(
        child: Column(
          children: [

            const AppTopBar(title: "Feedback"), // top bar title

            Padding(
              padding: const EdgeInsets.all(16), // padding around text field
              child: TextField(
                controller: _controller, // input controller
                maxLines: 8, // multiline input https://api.flutter.dev/flutter/material/TextField/maxLines.html
                decoration: const InputDecoration(
                  hintText: "Write your feedback...", // placeholder
                  border: OutlineInputBorder(), // border style https://api.flutter.dev/flutter/material/OutlineInputBorder-class.html
                ),
              ),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: accent, // pink background
                foregroundColor: Colors.white, // white text
              ),
              onPressed: _submit, // submit action
              child: const Text("Submit"), // button text
            ),

            const SizedBox(height: 12), // spacing

            Text(
              _message, // status message
              style: TextStyle(
                color: _message.contains("Thank") // choose colour
                    ? Colors.green // success
                    : Colors.red, // error
              ),
            ),
          ],
        ),
      ),
    );
  }
}