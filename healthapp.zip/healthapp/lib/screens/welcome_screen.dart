import 'package:flutter/material.dart'; // Flutter UI framework

class WelcomeScreen extends StatelessWidget { // Stateless widget for the welcome page
  const WelcomeScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  Widget build(BuildContext context) {  // Build method returns the UI - https://api.flutter.dev/flutter/widgets/Builder/build.html
    const bg = Color(0xFFF7E7E4); // Background blush colour
    const card = Color(0xFFFDF7F6);// Soft off‑white card colour
    const accent = Color(0xFFEAA6A0);  // Pink accent colour

    return Scaffold(  // Main page structure
      backgroundColor: bg, // Set page background
      body: SafeArea(   // Avoids notches/status bar
        child: Center( // Centers content horizontally
          child: SingleChildScrollView( // Allows scrolling on small screens
            padding: const EdgeInsets.symmetric(
                horizontal: 20, vertical: 24), // Page padding
            child: ConstrainedBox(
              constraints: const BoxConstraints(
                  maxWidth: 420), // Limits width for tablets
              child: Column(
                children: [
                  const SizedBox(height: 10), // Top spacing

                  // App icon circle
                  Container(
                    width: 96, height: 96, // Icon container size
                    decoration: BoxDecoration(
                      color: Colors.white, // White circle background
                      shape: BoxShape.circle, // Makes it circular
                      border: Border.all(
                          color: Colors.black12), // Subtle border
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 16, // Soft shadow blur
                          offset: Offset(0, 8), // Shadow position
                          color: Color(0x14000000), // Light shadow colour
                        ),
                      ],
                    ),
                    child: const Icon(
                        Icons.spa, // Spa icon - https://api.flutter.dev/flutter/material/Icons-class.html
                        size: 44,
                        color: accent), // Pink accent colour
                  ),

                  const SizedBox(height: 12), // Spacing under icon

                  const Text(
                    "HealthApp", // App title
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800),
                  ),

                  const SizedBox(height: 16), // Spacing before card

                  // Main welcome card
                  Container(
                    padding: const EdgeInsets.all(18), // Inner padding
                    decoration: BoxDecoration(
                      color: card, // Card background colour
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.black12),
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 18,
                          offset: Offset(0, 10),
                          color: Color(0x14000000),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        const Text(
                          "Discover Your\nBody, Mind, and\nConfidence",
                          textAlign: TextAlign.center,  // Centered heading
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              height: 1.15),
                        ),

                        const SizedBox(height: 10),

                        const Text(
                          "Everything you need to understand\nyour body and mind, in one place.",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.black54,
                              height: 1.3),
                        ),

                        const SizedBox(height: 18),

                        // Login button
                        SizedBox(
                          width: double.infinity, // Full width - https://docs.flutter.dev/ui/layout/constraints
                          height: 50, // Button height
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: accent,  // Pink background
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder( //https://api.flutter.dev/flutter/painting/RoundedRectangleBorder-class.html
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                            onPressed: () =>
                                Navigator.pushReplacementNamed( //https://api.flutter.dev/flutter/widgets/Navigator/pushReplacementNamed.html
                                    context, '/login'), // Navigate to login
                            child: const Text(
                              "Login",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800),
                            ),
                          ),
                        ),

                        const SizedBox(height: 10),

                        // Register button (outlined)
                        SizedBox(
                          width: double.infinity, //https://docs.flutter.dev/ui/layout/constraints
                          height: 50,
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(
                                  color: Colors.black12),  // Light border
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                              foregroundColor: Colors.black87,
                              backgroundColor: Colors.white,
                            ),
                            onPressed: () =>
                                Navigator.pushReplacementNamed( //https://api.flutter.dev/flutter/widgets/Navigator/pushReplacementNamed.html
                                    context, '/register'), // Navigate to register
                            child: const Text(
                              "Register",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800),
                            ),
                          ),
                        ),

                        const SizedBox(height: 6), // Bottom spacing
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}