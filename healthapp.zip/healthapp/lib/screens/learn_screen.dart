import 'package:flutter/material.dart'; // Flutter UI framework
import 'app_drawer.dart'; // Drawer widget
import 'app_topbar.dart'; // Custom top bar widget

class LearnScreen extends StatelessWidget { // Learn screen widget
  const LearnScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  static const Color bg = Color(0xFFF7E7E4); // background colour
  static const Color accent = Color(0xFFEAA6A0); // accent colour

  @override
  Widget build(BuildContext context) { // build UI
    return Scaffold( // main screen layout
      backgroundColor: bg, // set background colour
      drawer: const AppDrawer(), // slide-out drawer

      body: SafeArea( // avoid notches
        child: Column( // vertical layout
          crossAxisAlignment: CrossAxisAlignment.start, // align left
          children: [

            const AppTopBar(title: "Learn"), // top bar with title

            const Padding( // subtitle padding
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8), // padding values
              child: Text(
                "Trusted articles to guide you.", // subtitle text
                style: TextStyle(fontSize: 17), // text style
              ),
            ),

            const SizedBox(height: 20), // spacing

            Expanded( // fill remaining space
              child: GridView.count( // grid layout
                padding: const EdgeInsets.all(16), // grid padding
                crossAxisCount: 2, // two columns
                crossAxisSpacing: 16, // horizontal spacing
                mainAxisSpacing: 16, // vertical spacing
                children: [
                  _card(context, "Puberty", Icons.favorite, '/puberty'), // puberty card // icon https://api.flutter.dev/flutter/material/Icons-class.html
                  _card(context, "Contraception", Icons.shield, '/contraception'), // contraception card // icon https://api.flutter.dev/flutter/material/Icons-class.html
                  _card(context, "Emotions", Icons.mood, '/emotions'), // emotions card // icon https://api.flutter.dev/flutter/material/Icons-class.html
                  _card(context, "Pregnancy", Icons.child_friendly, '/pregnancy'), // pregnancy card // icon https://api.flutter.dev/flutter/material/Icons-class.html
                  _card(context, "Cycle", Icons.water_drop, '/cycle'), // cycle card // icon https://api.flutter.dev/flutter/material/Icons-class.html
                  _card(context, "Hygiene", Icons.clean_hands, '/hygiene'), // hygiene card // icon https://api.flutter.dev/flutter/material/Icons-class.html
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(BuildContext context, String title, IconData icon, String route) { // reusable card widget
    return InkWell( // tapable area of the card that responds to touch in an application  https://api.flutter.dev/flutter/material/InkWell-class.html
      onTap: () => Navigator.pushNamed(context, route), // navigate to topic https://api.flutter.dev/flutter/widgets/Navigator/pushNamed.html
      child: Container( // card container
        decoration: BoxDecoration(
          color: Colors.white, // card background
          borderRadius: BorderRadius.circular(16), // rounded corners
        ),
        child: Column( // card content layout
          mainAxisAlignment: MainAxisAlignment.center, // center vertically
          children: [
            Icon(icon, size: 40, color: accent), // card icon
            const SizedBox(height: 10), // spacing
            Text(title), // card title
          ],
        ),
      ),
    );
  }
}