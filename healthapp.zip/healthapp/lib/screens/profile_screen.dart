import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:cloud_firestore/cloud_firestore.dart'; // Firestore for loading/saving profile
import 'package:firebase_auth/firebase_auth.dart'; // Firebase auth for current user
import 'app_drawer.dart'; // Drawer menu widget
import 'app_topbar.dart'; // Custom top bar widget

class ProfileScreen extends StatefulWidget { // Screen for viewing/editing profile
  const ProfileScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _first = TextEditingController(); // First name input controller
  final _last = TextEditingController(); // Last name input controller
  final _email = TextEditingController(); // Email input controller
  final _phone = TextEditingController(); // Phone number input controller
  final _dob = TextEditingController(); // Date of birth input controller
  final _location = TextEditingController(); // Location input controller

  bool _loading = true; // Loading state while fetching profile
  String _message = ""; // Status message after update

  static const Color bg = Color(0xFFF7E7E4); // Background blush colour
  static const Color accent = Color(0xFFEAA6A0); // Pink accent colour

  @override
  void initState() {
    super.initState();
    _loadProfile(); // Load profile data on screen start
  }

  Future<void> _loadProfile() async { //future is for something that happens one time and then stops.
    final uid = FirebaseAuth.instance.currentUser!.uid; // Get current user's UID

    final doc = await FirebaseFirestore.instance //lab code
        .collection('users') // Users collection
        .doc(uid) // Document for this user
        .get(); // Fetch profile data

    if (doc.exists) { //lab code
      final data = doc.data()!; // Convert snapshot to map
      _first.text = data['firstName'] ?? ""; // Load first name
      _last.text = data['lastName'] ?? ""; // Load last name
      _email.text = data['email'] ?? "";  // Load email
      _phone.text = data['phone'] ?? ""; // Load phone
      _dob.text = data['dob'] ?? "";  // Load date of birth
      _location.text = data['location'] ?? ""; // Load location
    }

    setState(() => _loading = false);  // Stop loading spinner
  }

  Future<void> _updateProfile() async { //future is for something that happens one time and then stops.
    final uid = FirebaseAuth.instance.currentUser!.uid; // Current user's UID

    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .set({
      'firstName': _first.text.trim(), // Save first name https://api.flutter.dev/flutter/dart-core/String/trim.html
      'lastName': _last.text.trim(), // Save last name https://api.flutter.dev/flutter/dart-core/String/trim.html
      'email': _email.text.trim(), // Save email https://api.flutter.dev/flutter/dart-core/String/trim.html
      'phone': _phone.text.trim(), // Save phone https://api.flutter.dev/flutter/dart-core/String/trim.html
      'dob': _dob.text.trim(), // Save date of birth https://api.flutter.dev/flutter/dart-core/String/trim.html
      'location': _location.text.trim(), // Save location https://api.flutter.dev/flutter/dart-core/String/trim.html
    }, SetOptions(merge: true)); // Merge with existing data

    setState(() => _message = "Profile updated!"); // Show success message https://pub.dev/documentation/firebase/latest/firebase_firestore/SetOptions-class.html
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg, // Set screen background
      drawer: const AppDrawer(), // Drawer menu
      resizeToAvoidBottomInset: true, // Prevent keyboard overflow https://api.flutter.dev/flutter/material/Scaffold/resizeToAvoidBottomInset.html

      body: SafeArea(
        child: Column(
          children: [
            const AppTopBar(title: "Profile"), // Custom top bar with title

            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator()) // Show spinner while loading https://api.flutter.dev/flutter/material/CircularProgressIndicator-class.html
                  : SingleChildScrollView(
                padding: const EdgeInsets.all(16), // Page padding
                child: Column(
                  children: [
                    TextField( //https://docs.flutter.dev/cookbook/forms/text-input
                      controller: _first, // First name field
                      decoration: const InputDecoration(labelText: "First Name"),
                    ),
                    TextField( //https://docs.flutter.dev/cookbook/forms/text-input
                      controller: _last, // Last name field
                      decoration: const InputDecoration(labelText: "Last Name"),
                    ),
                    TextField( //https://docs.flutter.dev/cookbook/forms/text-input
                      controller: _email, // Email field
                      decoration: const InputDecoration(labelText: "Email"),
                    ),
                    TextField( //https://docs.flutter.dev/cookbook/forms/text-input
                      controller: _phone, // Phone field
                      decoration: const InputDecoration(labelText: "Phone"),
                    ),
                    TextField( //https://docs.flutter.dev/cookbook/forms/text-input
                      controller: _dob,  // Date of birth field
                      decoration: const InputDecoration(labelText: "Date of Birth"),
                    ),
                    TextField( //https://docs.flutter.dev/cookbook/forms/text-input
                      controller: _location, // Location field
                      decoration: const InputDecoration(labelText: "Location"),
                    ),

                    const SizedBox(height: 20),

                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: accent, // Pink button
                        foregroundColor: Colors.white,
                      ),
                      onPressed: _updateProfile, // Save profile changes
                      child: const Text("Update"),
                    ),

                    const SizedBox(height: 12),

                    Text(
                      _message, // Show success/error message
                      style: TextStyle(
                        color: _message.contains("updated")
                            ? Colors.green // Green for success
                            : Colors.red, // Red for errors
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}