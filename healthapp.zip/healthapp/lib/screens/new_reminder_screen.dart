import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:cloud_firestore/cloud_firestore.dart'; // Firestore for saving reminders
import 'package:firebase_auth/firebase_auth.dart'; // Firebase auth for user email

class NewReminderScreen extends StatefulWidget { // screen for creating a new reminder
  const NewReminderScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  State<NewReminderScreen> createState() => _NewReminderScreenState(); // create state
}

class _NewReminderScreenState extends State<NewReminderScreen> {
  final TextEditingController _titleController = TextEditingController(); // title input
  final TextEditingController _descController = TextEditingController(); // description input

  DateTime? _selectedDate; // chosen date https://api.flutter.dev/flutter/dart-core/DateTime-class.html
  TimeOfDay? _selectedTime; // chosen time https://api.flutter.dev/flutter/material/TimeOfDay-class.html

  bool _loading = false; // loading state
  String _message = ""; // error message

  static const Color bg = Color(0xFFF7E7E4); // background colour
  static const Color card = Color(0xFFFDF7F6); // card background
  static const Color accent = Color(0xFFEAA6A0); // pink accent

  @override
  void dispose() { // cleanup controllers
    _titleController.dispose();
    _descController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async { // open date picker - future is for something that happens one time and then stops.
    final today = DateTime.now(); // https://api.flutter.dev/flutter/dart-core/DateTime-class.html

    final picked = await showDatePicker( //https://api.flutter.dev/flutter/material/showDatePicker.html
      context: context,
      initialDate: _selectedDate ?? today, // default today
      firstDate: DateTime(today.year - 1), // past year https://api.flutter.dev/flutter/dart-core/DateTime-class.html
      lastDate: DateTime(today.year + 5), // next 5 years https://api.flutter.dev/flutter/dart-core/DateTime-class.html
    );

    if (picked != null) {
      setState(() => _selectedDate = picked); // save date https://api.flutter.dev/flutter/widgets/State/setState.html
    }
  }

  Future<void> _pickTime() async { // open time picker - future is for something that happens one time and then stops.
    final picked = await showTimePicker( // https://api.flutter.dev/flutter/material/showTimePicker.html
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(), // default now https://api.flutter.dev/flutter/material/TimeOfDay-class.html
    );

    if (picked != null) {
      setState(() => _selectedTime = picked); // save time https://api.flutter.dev/flutter/widgets/State/setState.html
    }
  }

  DateTime? _combineDateTime() { // combine date + time
    if (_selectedDate == null || _selectedTime == null) return null;

    return DateTime( // https://api.flutter.dev/flutter/dart-core/DateTime-class.html
      _selectedDate!.year,
      _selectedDate!.month,
      _selectedDate!.day,
      _selectedTime!.hour,
      _selectedTime!.minute,
    );
  }

  Future<void> _addReminder() async { // save reminder - future is for something that happens one time and then stops.
    final title = _titleController.text.trim(); // title text
    final desc = _descController.text.trim(); // description text
    final dueAt = _combineDateTime(); // combined datetime

    if (title.isEmpty) { // validate title
      setState(() => _message = "Please enter a title."); //https://api.flutter.dev/flutter/widgets/State/setState.html
      return;
    }
    if (dueAt == null) { // validate date/time
      setState(() => _message = "Please pick a date and time."); //https://api.flutter.dev/flutter/widgets/State/setState.html
      return;
    }

    setState(() { //https://api.flutter.dev/flutter/widgets/State/setState.html
      _loading = true; // show spinner
      _message = "";
    });

    try {
      await FirebaseFirestore.instance //lab code for authentification
          .collection('reminders')
          .add({
        'title': title, // reminder title
        'description': desc, // optional description
        'dueAt': Timestamp.fromDate(dueAt), // due datetime
        'isDone': false, // default not done
        'userEmail': FirebaseAuth.instance.currentUser?.email ?? "Guest", // owner
        'createdAt': FieldValue.serverTimestamp(), // server timestamp
      });

      if (!mounted) return;

      Navigator.pop(context); // return to list https://api.flutter.dev/flutter/widgets/Navigator/pop.html

    } catch (e) {
      setState(() => _message = "Error adding reminder."); // error message //https://api.flutter.dev/flutter/widgets/State/setState.html

    } finally {
      if (mounted) setState(() => _loading = false); // stop spinner //https://api.flutter.dev/flutter/widgets/State/setState.html
    }
  }

  String _formatDate(DateTime? d) { // format date label
    if (d == null) return "Pick date"; //https://dart.dev/null-safety
    return "${d.day}/${d.month}/${d.year}"; //https://api.flutter.dev/flutter/dart-core/DateTime-class.html
  }

  String _formatTime(TimeOfDay? t) { // format time label  https://api.flutter.dev/flutter/material/TimeOfDay-class.html
    if (t == null) return "Pick time"; //https://dart.dev/null-safety
    final h = t.hour.toString().padLeft(2, '0'); // https://api.flutter.dev/flutter/dart-core/String/padLeft.html
    final m = t.minute.toString().padLeft(2, '0'); // https://api.flutter.dev/flutter/dart-core/String/padLeft.html
    return "$h:$m"; //return hour and minutes
  }

  @override
  Widget build(BuildContext context) { // build UI
    return Scaffold(
      backgroundColor: bg, // screen background
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16), // page padding
          child: Column(
            children: [

              Align(
                alignment: Alignment.centerLeft, // align back button
                child: IconButton(
                  icon: const Icon(Icons.arrow_back), // back icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                  onPressed: () => Navigator.pop(context), // go back
                ),
              ),

              Container(
                width: double.infinity, //https://docs.flutter.dev/ui/layout/constraints
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: card, // title card background
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.black12),
                ),
                child: const Text(
                  "New Reminder", // screen title
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ),

              const SizedBox(height: 16),

              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white, // form card background
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.black12),
                ),
                child: Column(
                  children: [

                    TextField(
                      controller: _titleController, // title field
                      decoration: const InputDecoration(
                        labelText: "Title",
                        border: OutlineInputBorder(),
                      ),
                    ),

                    const SizedBox(height: 12),

                    TextField(
                      controller: _descController, // description field
                      decoration: const InputDecoration(
                        labelText: "Description (optional)",
                        border: OutlineInputBorder(),
                      ),
                    ),

                    const SizedBox(height: 12),

                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _pickDate, // pick date
                            icon: const Icon(Icons.calendar_month), // icon https://api.flutter.dev/flutter/material/Icons-class.html
                            label: Text(_formatDate(_selectedDate)), //show the user selected date
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _pickTime, // pick time
                            icon: const Icon(Icons.access_time), // icon https://api.flutter.dev/flutter/material/Icons-class.html
                            label: Text(_formatTime(_selectedTime)), //show the user selected time
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 12),

                    SizedBox(
                      width: double.infinity, //https://docs.flutter.dev/ui/layout/constraints
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: accent, // pink button
                          foregroundColor: Colors.white,
                        ),
                        onPressed: _loading ? null : _addReminder, // disable while loading
                        child: _loading
                            ? const CircularProgressIndicator(color: Colors.white)
                            : const Text("Add Reminder"), // button text
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 12),

              if (_message.isNotEmpty) //https://api.flutter.dev/flutter/package-collection_collection/DelegatingList/isNotEmpty.html
                Text(
                  _message, // error message
                  style: const TextStyle(color: Colors.red),
                ),
            ],
          ),
        ),
      ),
    );
  }
}