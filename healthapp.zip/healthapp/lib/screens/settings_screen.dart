import 'package:flutter/material.dart'; // Flutter UI framework
import 'app_drawer.dart';  // drawer widget
import 'app_topbar.dart'; // custom top bar widget

class SettingsScreen extends StatefulWidget { // settings screen widget
  const SettingsScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  State<SettingsScreen> createState() => _SettingsScreenState(); // create state
}

class _SettingsScreenState extends State<SettingsScreen> {
  static const Color bg = Color(0xFFF7E7E4);  // background colour
  static const Color accent = Color(0xFFEAA6A0); // pink accent

  String _fontSize = "Small"; // selected font size
  String _language = "English"; // selected language
  bool _isLightMode = true; // light mode toggle
  bool _notifications = true; // notifications toggle
  bool _vibration = false; // vibration toggle

  @override
  Widget build(BuildContext context) { // build UI
    return Scaffold(
      backgroundColor: bg, // set background colour
      drawer: const AppDrawer(), // drawer menu

      body: SafeArea(
        child: Column(
          children: [
            const AppTopBar(title: "Settings"), // top bar title

            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16), // page padding
                children: [

                  ListTile( //https://api.flutter.dev/flutter/material/ListTile-class.html
                    title: const Text("Font Size"), // label
                    trailing: DropdownButton<String>( // dropdown https://api.flutter.dev/flutter/material/DropdownButton-class.html
                      value: _fontSize, // current value
                      items: const [
                        DropdownMenuItem(value: "Small", child: Text("Small")),// https://api.flutter.dev/flutter/material/DropdownMenuItem-class.html
                        DropdownMenuItem(value: "Medium", child: Text("Medium")),
                        DropdownMenuItem(value: "Large", child: Text("Large")),
                      ],
                      onChanged: (value) { // update value
                        setState(() => _fontSize = value!);
                      },
                    ),
                  ),

                  ListTile( //https://api.flutter.dev/flutter/material/ListTile-class.html
                    title: const Text("Language"), // label
                    trailing: DropdownButton<String>( // dropdown https://api.flutter.dev/flutter/material/DropdownButton-class.html
                      value: _language, // current value
                      items: const [
                        DropdownMenuItem(value: "English", child: Text("English")),// https://api.flutter.dev/flutter/material/DropdownMenuItem-class.html
                        DropdownMenuItem(value: "Spanish", child: Text("Spanish")),
                        DropdownMenuItem(value: "French", child: Text("French")),
                      ],
                      onChanged: (value) {
                        setState(() => _language = value!); // update value
                      },
                    ),
                  ),

                  SwitchListTile( //https://api.flutter.dev/flutter/material/SwitchListTile-class.html
                    title: const Text("Light Mode"), // label
                    value: _isLightMode, // toggle state
                    activeThumbColor: accent, // pink thumb
                    activeTrackColor: accent.withValues(alpha: 0.4), // pink track
                    onChanged: (value) {
                      setState(() => _isLightMode = value); // update toggle
                    },
                  ),

                  SwitchListTile( //https://api.flutter.dev/flutter/material/SwitchListTile-class.html
                    title: const Text("Notifications"), // label
                    value: _notifications, // toggle state
                    activeThumbColor: accent, // pink thumb
                    activeTrackColor: accent.withValues(alpha: 0.4), // pink track
                    onChanged: (value) {
                      setState(() => _notifications = value); // update toggle
                    },
                  ),

                  SwitchListTile( //https://api.flutter.dev/flutter/material/SwitchListTile-class.html
                    title: const Text("Vibration"), // label
                    value: _vibration, // toggle state
                    activeThumbColor: accent, // pink thumb
                    activeTrackColor: accent.withValues(alpha: 0.4), // pink track
                    onChanged: (value) {
                      setState(() => _vibration = value); // update toggle
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
