import 'package:flutter/material.dart'; // Flutter UI framework
import 'app_drawer.dart'; // app drawer widget
import 'app_topbar.dart'; // custom top bar widget

class AboutScreen extends StatelessWidget { // about screen widget
  const AboutScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  static const Color bg = Color(0xFFF7E7E4); // background colour

  @override
  Widget build(BuildContext context) { // build UI
    return Scaffold(
      backgroundColor: bg, // set background colour
      drawer: const AppDrawer(), // app drawer

      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // align left -https://api.flutter.dev/flutter/rendering/CrossAxisAlignment.html
          children: [

            const AppTopBar(title: "About"), // top bar title

            const Padding(
              padding: EdgeInsets.all(16), // padding around text
              child: Text(
                "HealthApp is an educational mobile application designed to "
                    "help users learn about important health topics such as puberty, "
                    "contraception, emotions, pregnancy, menstrual cycles, and hygiene.\n\n"
                    "The goal of the app is to provide trusted, easy-to-understand "
                    "information in one safe and accessible place.\n\n"
                    "Technologies used:\n"
                    "- Flutter Mobile Development\n"
                    "- Firebase Authentication\n"
                    "- Firestore Database\n\n"
                    "Version: 3.83.1\n"
                    "Developed by: Francesca Donea", // about text
                style: TextStyle(fontSize: 18, height: 1.6), // text style
              ),
            ),

            const Spacer(), // push footer to bottom - https://api.flutter.dev/flutter/widgets/Spacer-class.html

            const Center(
              child: Padding(
                padding: EdgeInsets.only(bottom: 16), // bottom padding
                child: Text(
                  "© 2026 HealthApp", // footer text
                  style: TextStyle(color: Colors.black54), // grey text
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
