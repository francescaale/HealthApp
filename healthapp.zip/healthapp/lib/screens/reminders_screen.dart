
import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:cloud_firestore/cloud_firestore.dart';  // Firestore database
import 'package:firebase_auth/firebase_auth.dart'; // Firebase authentication
import 'app_drawer.dart'; // Drawer menu widget
import 'app_topbar.dart'; // Custom top bar widget

class ReminderScreen extends StatelessWidget {   // Stateless widget for reminders
  const ReminderScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  static const Color bg = Color(0xFFF7E7E4); // Background blush colour
  static const Color accent = Color(0xFFEAA6A0);  // Pink accent colour

  // Formats Firestore Timestamp into dd/mm/yyyy hh:mm
  String _formatDate(Timestamp? ts) {
    if (ts == null) return "No date"; // If no date stored
    final d = ts.toDate();  // Convert to DateTime
    return "${d.day}/${d.month}/${d.year}  "
        "${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}";
  }

  @override
  Widget build(BuildContext context) {
    final userEmail = FirebaseAuth.instance.currentUser?.email ?? "Guest"; // Logged‑in user email

    return Scaffold(
      backgroundColor: bg, // Page background colour
      drawer: const AppDrawer(), // Drawer menu

      floatingActionButton: FloatingActionButton(  // Add reminder button
        backgroundColor: accent,
        onPressed: () => Navigator.pushNamed(context, '/newReminder'),
        child: const Icon(Icons.add, color: Colors.white), // icon https://api.flutter.dev/flutter/material/Icons-class.html
      ),

      body: SafeArea(  // Avoids notches/status bar
        child: Column(
          children: [

            const AppTopBar(title: "Reminders"), // Custom top bar with title

            Expanded(   // Fills remaining space
              child: StreamBuilder<QuerySnapshot>(  // Live Firestore listener
                stream: FirebaseFirestore.instance
                    .collection('reminders') // Collection name
                    .where('userEmail', isEqualTo: userEmail) // Only reminders for this user
                    .snapshots(), // Real‑time updates

                builder: (context, snapshot) {

                  // While loading Firestore data
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  final docs = snapshot.data!.docs; // List of reminder documents

                  // If user has no reminders
                  if (docs.isEmpty) {
                    return const Center(child: Text("No reminders yet."));
                  }

                  return ListView.builder(  // Scrollable list of reminders
                    padding: const EdgeInsets.all(16),
                    itemCount: docs.length, // Number of reminders
                    itemBuilder: (context, index) {

                      final doc = docs[index]; // Current Firestore document
                      final data = doc.data() as Map<String, dynamic>; // Convert to map

                      return Card(
                        child: ListTile(
                          title: Text(data['title'] ?? ''),   // Reminder title
                          subtitle: Text(_formatDate(data['dueAt'])), // Formatted date/time

                          trailing: IconButton(  // Delete button
                            icon: const Icon(Icons.delete, color: Colors.red), // icon https://api.flutter.dev/flutter/material/Icons-class.html
                            onPressed: () async {
                              await doc.reference.delete(); // Delete reminder from Firestore https://stackoverflow.com/questions/53994972/flutter-remove-a-firebase-document-ontap
                            },
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
