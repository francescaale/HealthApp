import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  State<LoginScreen> createState() => _LoginScreenState(); //create state
}

class _LoginScreenState extends State<LoginScreen> {
  // This key helps us validate the form (email + password) lab code
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  // Controllers let us read what the user types
  final TextEditingController _emailController = TextEditingController(); //lab code
  final TextEditingController _passwordController = TextEditingController(); //lab code

  // Simple UI states
  bool _loading = false; // shows spinner on the button https://api.flutter.dev/flutter/dart-core/bool-class.html
  bool _hidePassword = true; // hide/show password text https://api.flutter.dev/flutter/dart-core/bool-class.html
  String _message = ""; // error messages to show on screen

  @override
  void dispose() {
    // Dispose controllers in Flutter to avoid memory leaks
    _emailController.dispose(); //lab code
    _passwordController.dispose(); //lab code
    super.dispose();
  }

  // Convert Firebase error codes into simple messages - extension work code lab errors
  String _loginError(String code, String? fallback) {
    switch (code) {
      case 'user-not-found':
        return 'No account found for that email.';
      case 'wrong-password':
        return 'Incorrect password.';
      case 'invalid-email':
        return 'That email address is not valid.';
      case 'network-request-failed':
        return 'Network error. Check your internet connection.';
      default:
        return fallback ?? 'Login failed.';
    }
  }

  // This runs when the user presses "Sign in"
  Future<void> _login() async { //future is for something that happens one time and then stops.
    // Close keyboard
    FocusScope.of(context).unfocus(); // removes focus from the text field, which dismisses the on-screen keyboard after user interaction https://api.flutter.dev/flutter/widgets/FocusScope-class.html https://api.flutter.dev/flutter/widgets/FocusNode/unfocus.html

    // If form is not valid (empty fields), stop here
    if (!_formKey.currentState!.validate()) return; //lab code

    // Update UI state before starting login
    setState(() {
      _loading = true;
      _message = "";
    });

    try {
      // Sign in with Firebase using the typed email + password
      final userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailController.text.trim(), // trim removes extra spaces at the beginning and end of the email
        password: _passwordController.text.trim(), // trim removes extra spaces at the beginning and end of the password
      );

      // If login worked, userCredential.user will NOT be null
      if (userCredential.user != null) {
        if (!mounted) return;

        // Go to Home and remove all previous pages
        // This means the back button will NOT go back to login screen
        Navigator.pushNamedAndRemoveUntil( //https://api.flutter.dev/flutter/widgets/Navigator/pushNamedAndRemoveUntil.html
          context,
          '/home',
              (route) => false,
        );
      }
    } on FirebaseAuthException catch (e) { //https://dart.dev/language/error-handling
      // Firebase gave an error (wrong password, etc.)
      setState(() {
        _message = _loginError(e.code, e.message);
      });
    } catch (e) { // https://dart.dev/language/error-handling
      // Any other error
      setState(() {
        _message = "Something went wrong. Please try again.";
      });
    } finally {
      // Stop loading spinner
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override // override build method
  Widget build(BuildContext context) { // build UI
    const bg = Color(0xFFF7E7E4); // background colour
    const card = Color(0xFFFDF7F6); // card background colour
    const accent = Color(0xFFEAA6A0); // accent colour

    return Scaffold( // main screen structure
      backgroundColor: bg, // set background colour
      body: SafeArea( // avoid notches
        child: Center( // center content
          child: SingleChildScrollView( // allow scrolling
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24), // page padding
            child: ConstrainedBox( // limit width
              constraints: const BoxConstraints(maxWidth: 420), // max width for layout
              child: Column( // vertical layout
                children: [
                  const SizedBox(height: 10), // spacing

                  Container( // top icon circle
                    width: 96, // circle width
                    height: 96, // circle height
                    decoration: BoxDecoration( // circle styling
                      color: Colors.white, // white background
                      shape: BoxShape.circle, // circular shape
                      border: Border.all(color: Colors.black12), // light border
                      boxShadow: const [ // soft shadow
                        BoxShadow(
                          blurRadius: 16, // shadow blur
                          offset: Offset(0, 8), // shadow offset
                          color: Color(0x14000000), // shadow colour
                        ),
                      ],
                    ),
                    child: const Icon(Icons.favorite, size: 40, color: accent), // heart icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                  ),

                  const SizedBox(height: 12), // spacing

                  const Text( // app title
                    "HealthApp",
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800), // title style
                  ),

                  const SizedBox(height: 16), // spacing

                  Container( // main card container
                    padding: const EdgeInsets.all(18), // inner padding
                    decoration: BoxDecoration( // card styling
                      color: card, // card background
                      borderRadius: BorderRadius.circular(18), // rounded corners
                      border: Border.all(color: Colors.black12), // border
                      boxShadow: const [ // shadow
                        BoxShadow(
                          blurRadius: 18, // blur
                          offset: Offset(0, 10), // offset
                          color: Color(0x14000000), // colour
                        ),
                      ],
                    ),
                    child: Form( // form wrapper
                      key: _formKey, // form key for validation
                      child: Column( // form layout
                        crossAxisAlignment: CrossAxisAlignment.stretch, // stretch children
                        children: [
                          const Text( // login title
                            "Login",
                            textAlign: TextAlign.center, // center text
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800), // style
                          ),

                          const SizedBox(height: 6), // spacing

                          const Text( // subtitle
                            "Welcome back. Continue your journey.",
                            textAlign: TextAlign.center, // center text
                            style: TextStyle(color: Colors.black54), // grey text
                          ),

                          const SizedBox(height: 18), // spacing

                          TextFormField( // email input
                            controller: _emailController, // email controller
                            keyboardType: TextInputType.emailAddress, // email keyboard
                            decoration: InputDecoration( // input styling
                              labelText: "Email", // label
                              hintText: "hello@gmail.com", // hint
                              filled: true, // filled background
                              fillColor: Colors.white, // white fill
                              border: OutlineInputBorder( // border style
                                borderRadius: BorderRadius.circular(14), // rounded border
                              ),
                            ),
                            validator: (value) { // email validation - lab code
                              final text = (value ?? '').trim(); // trim input
                              if (text.isEmpty) return "Email is required."; // empty check
                              if (!text.contains('@')) return "Enter a valid email."; // format check
                              return null; // valid
                            },
                          ),

                          const SizedBox(height: 12), // spacing

                          TextFormField( // password input
                            controller: _passwordController, // password controller
                            obscureText: _hidePassword, // hide/show password
                            decoration: InputDecoration( // styling
                              labelText: "Password", // label
                              hintText: "••••••••", // hint
                              filled: true, // filled background
                              fillColor: Colors.white, // white fill
                              border: OutlineInputBorder( // border
                                borderRadius: BorderRadius.circular(14), // rounded border
                              ),
                              suffixIcon: IconButton( // visibility toggle
                                onPressed: () {
                                  setState(() => _hidePassword = !_hidePassword); // toggle state
                                },
                                icon: Icon(_hidePassword
                                    ? Icons.visibility_off
                                    : Icons.visibility), // icon based on state // icon https://api.flutter.dev/flutter/material/Icons-class.html
                              ),
                            ),
                            validator: (value) { // password validation - lab code
                              final text = (value ?? '').trim(); // trim input
                              if (text.isEmpty) return "Password is required."; // empty check
                              if (text.length < 6) return "Min 6 characters."; // length check
                              return null; // valid
                            },
                          ),

                          const SizedBox(height: 10), // spacing

                          if (_message.isNotEmpty) ...[ // show error if exists https://api.dart.dev/dart-core/String/isNotEmpty.html
                            Container(
                              padding: const EdgeInsets.all(12), // padding
                              decoration: BoxDecoration( // error box styling
                                color: const Color(0xFFFFE6E6), // light red background
                                borderRadius: BorderRadius.circular(12), // rounded corners
                                border: Border.all(color: const Color(0x33FF0000)), // red border
                              ),
                              child: Row( // error row
                                children: [
                                  const Icon(Icons.error_outline, color: Colors.red), // error icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                                  const SizedBox(width: 10), // spacing
                                  Expanded(
                                    child: Text(
                                      _message, // error message text
                                      style: const TextStyle(color: Colors.red), // red text
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 10), // spacing
                          ],

                          SizedBox(
                            height: 50, // button height
                            child: ElevatedButton( // login button
                              style: ElevatedButton.styleFrom(
                                backgroundColor: accent, // pink background
                                foregroundColor: Colors.white, // white text
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14), // rounded button
                                ),
                              ),
                              onPressed: _loading ? null : _login, // disable if loading
                              child: _loading
                                  ? const SizedBox(
                                width: 20, // spinner width
                                height: 20, // spinner height
                                child: CircularProgressIndicator(strokeWidth: 2), // spinner https://api.flutter.dev/flutter/material/CircularProgressIndicator-class.html
                              )
                                  : const Text(
                                "Sign in", // button text
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800), // style
                              ),
                            ),
                          ),

                          const SizedBox(height: 14), // spacing

                          Row(
                            mainAxisAlignment: MainAxisAlignment.center, // center row
                            children: [
                              const Text("Don't have an account? "), // text
                              TextButton(
                                onPressed: () {
                                  Navigator.pushReplacementNamed(context, '/register'); // go to register https://api.flutter.dev/flutter/widgets/Navigator/pushReplacementNamed.html
                                },
                                child: const Text("Register"), // register link
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}