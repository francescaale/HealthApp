import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:introduction_screen/introduction_screen.dart'; // tutorial pages package

class TutorialScreen extends StatelessWidget { // tutorial screen widget
  const TutorialScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  static const Color bg = Color(0xFFF7E7E4); // background colour
  static const Color accent = Color(0xFFEAA6A0); // pink accent

  @override
  Widget build(BuildContext context) { // build UI
    return Scaffold(
      backgroundColor: bg, // set background colour
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft, // align back button left
              child: IconButton(
                icon: const Icon(Icons.arrow_back, size: 28), // back icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                color: accent, // pink colour
                onPressed: () => Navigator.pop(context), // go back
              ),
            ),

            Expanded(
              child: IntroductionScreen( //https://pub.dev/packages/introduction_screen
                globalBackgroundColor: bg, // background for all pages

                controlsPadding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 8), // padding for buttons
                controlsMargin: const EdgeInsets.all(8), // margin around controls

                skipOrBackFlex: 1, // layout proportions
                nextFlex: 1, //https://pub.dev/packages/introduction_screen
                dotsFlex: 2, //https://pub.dev/packages/introduction_screen

                showSkipButton: true, // show skip button https://pub.dev/packages/introduction_screen
                skip: Text("Skip",
                    style: TextStyle(color: accent, fontSize: 14)), // skip text
                next: Icon(Icons.arrow_forward, color: accent), // next arrow // icon https://api.flutter.dev/flutter/material/Icons-class.html
                done: Text(
                  "Done", // done text
                  style: TextStyle(
                      color: accent,
                      fontWeight: FontWeight.bold,
                      fontSize: 14),
                ),
                onDone: () => Navigator.pop(context), // close tutorial https://api.flutter.dev/flutter/dart-async/StreamSubscription/onDone.html

                pages: [

                  PageViewModel( // page 1 //https://pub.dev/packages/introduction_screen
                    titleWidget: Column(
                      children: [
                        Icon(Icons.favorite, // icon https://api.flutter.dev/flutter/material/Icons-class.html
                            size: 80,
                            color: accent.withValues(alpha: 0.8)), // faded icon
                        const SizedBox(height: 20),
                        const Text(
                          "Welcome", // page title
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    bodyWidget: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        "This app is a safe and supportive space to learn about your health, ask questions, and find trusted information.", // body text
                        style: TextStyle(fontSize: 18),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),

                  PageViewModel( // page 2 //https://pub.dev/packages/introduction_screen
                    titleWidget: Column(
                      children: [
                        Icon(Icons.wb_sunny, // icon https://api.flutter.dev/flutter/material/Icons-class.html
                            size: 80,
                            color: accent.withValues(alpha: 0.8)), // sun icon
                        const SizedBox(height: 20),
                        const Text(
                          "Learn About Your Body", // title
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    bodyWidget: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        "Explore topics like puberty, contraception, emotions, pregnancy, the menstrual cycle, and hygiene.", // body text
                        style: TextStyle(fontSize: 18),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),

                  PageViewModel( // page 3 //https://pub.dev/packages/introduction_screen
                    titleWidget: Column(
                      children: [
                        Icon(Icons.video_collection, // icon https://api.flutter.dev/flutter/material/Icons-class.html
                            size: 80,
                            color: accent.withValues(alpha: 0.8)), // video icon
                        const SizedBox(height: 20),
                        const Text(
                          "Articles & Videos", // title
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    bodyWidget: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        "Read simple articles and watch short videos to learn at your own pace.", // body text
                        style: TextStyle(fontSize: 18),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),

                  PageViewModel( // page 4 //https://pub.dev/packages/introduction_screen
                    titleWidget: Column(
                      children: [
                        Icon(Icons.chat_bubble_outline, // icon https://api.flutter.dev/flutter/material/Icons-class.html
                            size: 80,
                            color: accent.withValues(alpha: 0.8)), // chat icon
                        const SizedBox(height: 20),
                        const Text(
                          "Ask Anything", // title
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    bodyWidget: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        "Use the Ask Anything screen to get clear answers to your questions.", // body text
                        style: TextStyle(fontSize: 18),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),

                  PageViewModel( // page 5 //https://pub.dev/packages/introduction_screen
                    titleWidget: Column(
                      children: [
                        Icon(Icons.location_on, // icon https://api.flutter.dev/flutter/material/Icons-class.html
                            size: 80,
                            color: accent.withValues(alpha: 0.8)), // location icon
                        const SizedBox(height: 20),
                        const Text(
                          "Clinics & Reminders", // title
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    bodyWidget: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        "Find clinics near you, save articles, and set reminders for medicine, periods, or appointments.", // body text
                        style: TextStyle(fontSize: 18),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ],

                dotsDecorator: DotsDecorator( // dot styling https://pub.dev/packages/introduction_screen
                  activeColor: accent, // active dot colour
                  color: accent.withValues(alpha: 0.3), // inactive dot colour
                  size: const Size(10, 10), // dot size
                  activeSize: const Size(22, 10), // active dot elongated
                  activeShape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25), // pill shape
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
