import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:cloud_firestore/cloud_firestore.dart'; // Firestore database
import 'package:firebase_auth/firebase_auth.dart'; // Firebase authentication
import 'package:youtube_player_flutter/youtube_player_flutter.dart'; // YouTube player package

class CycleScreen extends StatefulWidget { // cycle screen widget
  const CycleScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  @override
  State<CycleScreen> createState() => _CycleScreenState(); // create state
}

class _CycleScreenState extends State<CycleScreen> {
  //adapted code https://pub.dev/packages/youtube_player_flutter
  late YoutubePlayerController _controller; // YouTube controller

  @override
  void initState() { // initialize state
    super.initState();

    //adapted code https://pub.dev/packages/youtube_player_flutter
    _controller = YoutubePlayerController( // setup YouTube player
      initialVideoId: "wtxQRuEmgyM", // video ID
      flags: const YoutubePlayerFlags(
        autoPlay: false, // do not autoplay
        mute: false, // sound enabled
      ),
    );
  }

  List<Widget> _buildFormattedContent(String content) { // format article text
    final paragraphs = content
        .split('\n\n') // Split text by blank lines https://api.dart.dev/stable/dart-core/String/split.html
        .where((p) => p.trim().isNotEmpty) // Remove empty sections - https://api.dart.dev/stable/dart-core/Iterable/where.html https://api.dart.dev/stable/dart-core/String/trim.html
        .toList(); //https://api.dart.dev/dart-core/Iterable/toList.html

    return paragraphs.map((paragraph) {
      final text = paragraph.trim();  // Clean whitespace - https://api.dart.dev/stable/dart-core/String/trim.html
      final isHeading = text.endsWith(':'); // Detect headings by colon https://api.dart.dev/dart-core/String/endsWith.html

      return Padding(
        padding: const EdgeInsets.only(bottom: 14), // spacing
        child: Text(
          text, // paragraph text
          style: TextStyle(
            fontSize: isHeading ? 18 : 16, // larger for headings
            fontWeight: isHeading ? FontWeight.bold : FontWeight.normal, // bold headings
            height: 1.7, // line spacing
            color: Colors.black87, // text colour
          ),
        ),
      );
    }).toList();// https://api.dart.dev/dart-core/Iterable/toList.html
  }

  @override
  void dispose() { // cleanup
    _controller.dispose(); // dispose YouTube controller //adapted code https://pub.dev/packages/youtube_player_flutter
    super.dispose();
  }

  @override
  Widget build(BuildContext context) { // build UI
    return Scaffold(
      backgroundColor: const Color(0xFFF7E7E4), // background colour
      body: SafeArea(
        child: FutureBuilder<DocumentSnapshot>( // load Firestore content - lab code
          future: FirebaseFirestore.instance // future is for something that happens one time and then stops.
              .collection('learn_topics') // topics collection
              .doc('cycle') // cycle document
              .get(), // fetch data
          builder: (context, snapshot) { //lab code
            if (!snapshot.hasData) { // loading state
              return const Center(child: CircularProgressIndicator());
            }

            if (!snapshot.data!.exists) { // no content found
              return const Center(child: Text("No cycle content found."));
            }

            final data = snapshot.data!.data() as Map<String, dynamic>; // convert to map -  lab code
            final title = (data['title'] ?? '').toString(); // article title
            final content = (data['content'] ?? '').toString(); // article content

            return SingleChildScrollView( // scrollable page
              padding: const EdgeInsets.all(16), // page padding
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, // align left
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back), // back button // icon https://api.flutter.dev/flutter/material/Icons-class.html
                    onPressed: () => Navigator.pop(context), // go back
                  ),
                  Text(
                    title, // article title
                    style: const TextStyle(
                      fontSize: 22, // title size
                      fontWeight: FontWeight.bold, // bold title
                    ),
                  ),
                  const SizedBox(height: 10), // spacing
                  ElevatedButton.icon(
                    icon: const Icon(Icons.bookmark, color: Colors.pink), // bookmark icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                    label: const Text(
                      "Save Article", // button text
                      style: TextStyle(color: Colors.pink), // pink text
                    ),
                    onPressed: () async { //lab code authentication
                      final user = FirebaseAuth.instance.currentUser; // current user
                      if (user == null) return; // stop if not logged in

                      await FirebaseFirestore.instance
                          .collection('saved_articles') // saved articles collection
                          .add({
                        'userEmail': user.email, // user email
                        'title': title, // article title
                        'content': content, // article content
                        'route': '/cycle', // route to reopen
                        'createdAt': Timestamp.now(), // timestamp
                      });

                      if (!context.mounted) return; // ensure widget still active https://api.flutter.dev/flutter/widgets/Element/mounted.html

                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Article saved")), // confirmation
                      );
                    },
                  ),
                  const SizedBox(height: 12), // spacing
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start, // align left
                    children: _buildFormattedContent(content), // formatted article
                  ),
                  const SizedBox(height: 25), // spacing
                  Container(
                    padding: const EdgeInsets.all(14), // padding
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16), // rounded corners
                      border: Border.all(
                        color: Colors.white, // white border
                        width: 4, // border width
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start, // align left
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.play_circle_fill,
                                color: Colors.pinkAccent), // play icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                            SizedBox(width: 8), // spacing
                            Text(
                              "Watch & Learn", // section title
                              style: TextStyle(
                                fontSize: 18, // text size
                                fontWeight: FontWeight.bold, // bold text
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6), // spacing
                        const Text(
                          "The Menstrual Cycle Explained", // video description
                          style: TextStyle(
                            fontSize: 14, // text size
                            color: Colors.black54, // grey text
                          ),
                        ),
                        const SizedBox(height: 12), // spacing
                        //https://api.flutter.dev/flutter/widgets/ClipRRect-class.html
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12), // rounded video corners
                          child: AspectRatio(
                            aspectRatio: 16 / 9, // video ratio
                            //https://pub.dev/packages/youtube_player_flutter
                            child: YoutubePlayer(
                              controller: _controller, // YouTube controller
                              showVideoProgressIndicator: true, // show progress bar
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20), // bottom spacing
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}