import 'package:flutter/material.dart';

class AppTopBar extends StatelessWidget {
  final String title; // page title text

  const AppTopBar({super.key, required this.title}); // required title for each page

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), // outer padding
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween, // space between left/title/right
        children: [

          // LEFT SIDE: Drawer menu button
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, size: 28), // menu icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
              onPressed: () {
                Scaffold.of(context).openDrawer(); // open drawer
              },
            ),
          ),

          // Page title
          Text(
            title, // dynamic title
            style: const TextStyle(
              fontSize: 20, // title size
              fontWeight: FontWeight.bold, // bold title
            ),
          ),

          //adapted code for 3 dot menu https://api.flutter.dev/flutter/material/PopupMenuButton-class.html
          // RIGHT SIDE: 3 dot menu
          PopupMenuButton<String>( // popup menu for extra actions
            icon: const Icon(Icons.more_vert), // 3-dot icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
            onSelected: (value) { // handle selected item
              if (value == "profile") {
                Navigator.pushNamed(context, '/profile'); // go to profile
              } else if (value == "tutorial") {
                Navigator.pushNamed(context, '/tutorial'); // go to tutorial
              } else if (value == "settings") {
                Navigator.pushNamed(context, '/settings'); // go to settings
              }
            },
            itemBuilder: (context) => const [

              PopupMenuItem(
                value: "profile", // returned when tapped
                child: Row(
                  children: [
                    Icon(Icons.person), // profile icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                    SizedBox(width: 10), // spacing
                    Text("Profile"), // label
                  ],
                ),
              ),

              PopupMenuItem(
                value: "tutorial",
                child: Row(
                  children: [
                    Icon(Icons.menu_book), // tutorial icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                    SizedBox(width: 10),
                    Text("Tutorial"),
                  ],
                ),
              ),

              PopupMenuItem(
                value: "settings",
                child: Row(
                  children: [
                    Icon(Icons.settings), // settings icon // icon https://api.flutter.dev/flutter/material/Icons-class.html
                    SizedBox(width: 10),
                    Text("Settings"),
                  ],
                ),
              ),

            ],
          ),
        ],
      ),
    );
  }
}