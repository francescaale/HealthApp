import 'package:flutter/material.dart'; // Flutter UI framework
import 'package:cloud_firestore/cloud_firestore.dart'; // Firestore database
import 'package:firebase_auth/firebase_auth.dart'; // Firebase authentication
import 'app_drawer.dart'; // Drawer menu widget
import 'app_topbar.dart'; // Custom top bar widget

class SavedScreen extends StatelessWidget { // Stateless widget for saved articles
  const SavedScreen({super.key}); // pass the key to class (stateless/stateful) to manage ui updates

  static const Color bg = Color(0xFFF7E7E4); // Background blush colour
  static const Color read = Color(0xFFE89EB8); // Pink colour for "Read" button

  @override
  Widget build(BuildContext context) {

    final user = FirebaseAuth.instance.currentUser; // Get current logged‑in user lab code

    // If user is not logged in, show message
    if (user == null) { //lab code
      return const Scaffold(
        body: Center(child: Text("Please log in")),
      );
    }

    return Scaffold(
      backgroundColor: bg, // Page background colour
      drawer: const AppDrawer(), // Drawer menu

      body: SafeArea(  // Avoids notches/status bar
        child: Column(
          children: [

            const AppTopBar(title: "Saved Articles"), // Custom top bar with title

            Expanded(  // Fills remaining space
              child: StreamBuilder<QuerySnapshot>(  // Live Firestore listener lab code
                stream: FirebaseFirestore.instance //lab code
                    .collection('saved_articles') // Collection name
                    .where('userEmail',   // Filter by logged‑in user
                    isEqualTo: user.email)
                    .snapshots(), // Listen for real‑time updates

                builder: (context, snapshot) { //labcode

                  // While loading Firestore data
                  if (!snapshot.hasData) {
                    return const Center(
                      child: CircularProgressIndicator(), // Loading spinner
                    );
                  }

                  final docs = snapshot.data!.docs; // List of saved article documents

                  // If user has no saved articles
                  if (docs.isEmpty) {
                    return const Center(
                      child: Text("No saved articles yet."),
                    );
                  }

                  return ListView.builder( // Scrollable list of saved items https://api.flutter.dev/flutter/widgets/ListView/ListView.builder.html
                    padding: const EdgeInsets.all(16),
                    itemCount: docs.length, // Number of saved articles
                    itemBuilder: (context, index) { // https://api.flutter.dev/flutter/widgets/IndexedWidgetBuilder.html

                      final doc = docs[index]; // Current Firestore document
                      final data = doc.data() as Map<String, dynamic>; // Convert to map https://pub.dev/documentation/cloud_firestore/latest/cloud_firestore/DocumentSnapshot-class.html https://api.dart.dev/dart-core/Map-class.html

                      final route = data['route']; // Route to open full article

                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment:  // Align text to the left
                            CrossAxisAlignment.start,
                            children: [

                              // Article title
                              Text(
                                data['title'] ?? '', // Title text
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                              const SizedBox(height: 6),

                              // Short preview of article content
                              Text(
                                data['content'] ?? '',  // Content preview
                                maxLines: 2, // Limit to 2 lines
                                overflow: TextOverflow.ellipsis, // Add "..." if too long
                              ),

                              const SizedBox(height: 10),

                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.end, // Buttons on the right
                                children: [

                                  // READ ARTICLE BUTTON
                                  TextButton(
                                    onPressed: () {
                                      if (route == null) {  // If no route saved
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          const SnackBar(
                                            content: Text(
                                              "This saved article cannot be opened.",
                                            ),
                                          ),
                                        );
                                        return;
                                      }

                                      Navigator.pushNamed( // Navigate to article page
                                          context, route);
                                    },
                                    child: const Text(
                                      "Read article",
                                      style: TextStyle(color: read),
                                    ),
                                  ),

                                  // DELETE BUTTON
                                  IconButton(
                                    icon: const Icon(
                                      Icons.delete, // icon https://api.flutter.dev/flutter/material/Icons-class.html
                                      color: Colors.red, // Red delete icon
                                    ),
                                    onPressed: () async { //https://dart.dev/language/async / https://api.flutter.dev/flutter/material/ElevatedButton-class.html
                                      await doc.reference // Delete Firestore document https://firebase.google.com/docs/firestore/manage-data/delete-data
                                          .delete();
                                    },
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}